#!/usr/bin/env bash
set -euo pipefail

GAME_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$GAME_DIR"

if ! command -v python3 >/dev/null 2>&1; then
    echo "Python 3 is required. Install it through your Linux software manager."
    exit 1
fi

if [ ! -f .venv/pyvenv.cfg ] || [ ! -x .venv/bin/python ]; then
    echo "Creating or repairing the private game environment..."
    python3 -m venv --clear .venv || {
        echo "Your system is missing Python's venv package."
        echo "On Ubuntu or Linux Mint run: sudo apt install python3-venv"
        exit 1
    }
fi

if ! .venv/bin/python -m pip --version >/dev/null 2>&1; then
    echo "Repairing Python package support..."
    python3 -m venv --clear .venv
fi

echo "Installing the graphical engine..."
.venv/bin/python -m pip install --disable-pip-version-check --no-input -r requirements.txt
chmod +x run.sh INSTALL.sh
echo
echo "Installation complete. Start the game with:"
echo "  $GAME_DIR/run.sh"
