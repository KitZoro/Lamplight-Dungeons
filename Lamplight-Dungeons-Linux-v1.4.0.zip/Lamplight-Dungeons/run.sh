#!/usr/bin/env bash
set -euo pipefail

GAME_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$GAME_DIR"
if [ ! -f .venv/pyvenv.cfg ] || [ ! -x .venv/bin/python ] || \
        ! .venv/bin/python -c 'import pygame' >/dev/null 2>&1; then
    echo "Lamplight Dungeons has not been installed yet. Running the installer..."
    ./INSTALL.sh
fi
exec .venv/bin/python game.py
