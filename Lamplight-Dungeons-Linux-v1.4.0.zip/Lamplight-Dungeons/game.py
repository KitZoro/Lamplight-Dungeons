#!/usr/bin/env python3
"""Lamplight Dungeons - a modern, room-driven mainframe-style dungeon RPG."""

from __future__ import annotations

import json
import random
from collections import deque
from pathlib import Path

try:
    import pygame
except ImportError:
    print("Lamplight Dungeons needs pygame-ce. Run ./INSTALL.sh first.")
    raise SystemExit(1)


ROOT = Path(__file__).resolve().parent
SAVE_FILE = ROOT / "savegame.json"
VERSION = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
WIDTH, HEIGHT = 1280, 720
PANEL = 320

RACES = {
    "Bunny": {"str": -2, "int": 0, "wis": 2, "con": -1, "dex": 3, "cha": 1},
    "Fox": {"str": 0, "int": 2, "wis": 0, "con": -1, "dex": 2, "cha": 1},
    "Ferret": {"str": -1, "int": 1, "wis": 0, "con": 1, "dex": 2, "cha": 0},
    "Cat": {"str": 0, "int": 1, "wis": 0, "con": 0, "dex": 2, "cha": 0},
    "Chicken": {"str": -2, "int": 0, "wis": 2, "con": 0, "dex": 1, "cha": 1},
    "Human": {"str": 0, "int": 0, "wis": 0, "con": 0, "dex": 0, "cha": 0},
}

CLASSES = {
    "Knight": {"hp": 35, "sp": 5, "attack": 7, "armor": 5, "main": "str", "skill": "Guard"},
    "Archer": {"hp": 28, "sp": 9, "attack": 6, "armor": 3, "main": "dex", "skill": "Aimed shot"},
    "Priest": {"hp": 26, "sp": 17, "attack": 4, "armor": 3, "main": "wis", "skill": "Healing prayer"},
    "Mage": {"hp": 23, "sp": 21, "attack": 3, "armor": 2, "main": "int", "skill": "Arcane bolt"},
}

DIRECTIONS = {
    "N": (0, -1, "North"),
    "S": (0, 1, "South"),
    "E": (1, 0, "East"),
    "W": (-1, 0, "West"),
}
OPPOSITE = {"N": "S", "S": "N", "E": "W", "W": "E"}

ROOMS = [
    ("Stone Gallery", "Rows of weathered faces watch from the walls.", (44, 55, 58)),
    ("Rootbound Hall", "Ancient roots have split the fitted stones.", (42, 58, 46)),
    ("Echoing Vault", "Every breath returns from the distant ceiling.", (51, 48, 60)),
    ("Forgotten Chapel", "A cracked sun-wheel hangs above a silent altar.", (60, 50, 39)),
    ("Flooded Passage", "Black water lies still between raised flagstones.", (34, 52, 61)),
    ("Ashen Guardroom", "Cold braziers flank an abandoned watch post.", (61, 42, 35)),
    ("Moonlit Crypt", "Pale mineral light leaks through the masonry.", (42, 48, 65)),
    ("Broken Archive", "Stone shelves hold the dust of vanished records.", (54, 48, 43)),
]

MONSTERS = [
    ("Giant white louse", 1, 8, 2, 7, 7, 13),
    ("Tunnel kobold", 1, 12, 3, 10, 9, 14),
    ("Goblin scavenger", 2, 17, 4, 14, 12, 14),
    ("Orc sentry", 4, 25, 5, 21, 18, 14),
    ("Crypt ghoul", 6, 34, 7, 30, 25, 13),
    ("Cave troll", 9, 49, 9, 43, 38, 14),
    ("Stone giant", 12, 68, 11, 64, 55, 14),
    ("Ash balrog", 16, 96, 14, 98, 82, 15),
    ("Red dragon", 19, 155, 18, 190, 165, 15),
]

SPECIES_COL = {name: i for i, name in enumerate(RACES)}
CLASS_ROW = {name: i for i, name in enumerate(CLASSES)}


def clamp(value, low, high):
    return max(low, min(high, value))


def valid_text(value, minimum, maximum, *, allow_blank=False):
    """Return whether save-file text is safe to display with pygame."""
    return (
        isinstance(value, str)
        and minimum <= len(value) <= maximum
        and (allow_blank or bool(value.strip()))
        and (not value or value.isprintable())
        and not any(0xD800 <= ord(character) <= 0xDFFF for character in value)
    )


def new_player(name, race, klass, classic):
    stats = {"str": 12, "int": 12, "wis": 12, "con": 12, "dex": 12, "cha": 12}
    for key, value in RACES[race].items():
        stats[key] += value
    hp = CLASSES[klass]["hp"] + max(0, stats["con"] - 10) * 2
    sp = CLASSES[klass]["sp"] + max(0, stats[CLASSES[klass]["main"]] - 10)
    return {
        "name": name.strip() or "Delver", "race": race, "class": klass,
        "classic": classic, "level": 1, "xp": 0, "next_xp": 18,
        "hp": hp, "max_hp": hp, "sp": sp, "max_sp": sp,
        "bank": 0, "carried": 0, "potions": 2, "rations": 3,
        "depth": 1, "deepest": 1, "kills": 0, "stats": stats, "won": False,
    }


class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Lamplight Dungeons")
        self.window = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
        self.canvas = pygame.Surface((WIDTH, HEIGHT))
        self.clock = pygame.time.Clock()
        self.fullscreen = False
        self.running = True
        self.font = pygame.font.SysFont("DejaVu Sans", 23)
        self.small = pygame.font.SysFont("DejaVu Sans", 18)
        self.tiny = pygame.font.SysFont("DejaVu Sans", 15)
        self.mono = pygame.font.SysFont("DejaVu Sans Mono", 21)
        self.mono_small = pygame.font.SysFont("DejaVu Sans Mono", 16)
        self.mono_big = pygame.font.SysFont("DejaVu Sans Mono", 31, bold=True)
        self.large = pygame.font.SysFont("DejaVu Sans", 45, bold=True)
        self.title_font = pygame.font.SysFont("DejaVu Sans", 76, bold=True)
        self.assets = self.load_assets()
        self.sounds = {}
        self.audio_ok = False
        self.audio_muted = False
        self.init_audio()

        self.state = "intro"
        self.intro_started = pygame.time.get_ticks()
        self.title_choice = 0
        self.create_row = 0
        self.create_values = ["Bunny", "Priest", "Adventure"]
        self.name_text = "Aster"
        self.player = None
        self.floor_seed = 0
        self.rooms = []
        self.location = 0
        self.previous_location = 0
        self.combat_enemy = None
        self.guard = False
        self.combat_choice = 0
        self.map_hitboxes = {}
        self.room_command_hitboxes = {}
        self.combat_hitboxes = {}
        self.messages = ["Welcome to Lamplight Dungeons."]
        self.last_command = ""

    def load_assets(self):
        atlas = pygame.image.load(ROOT / "assets" / "dungeon_atlas.png").convert()
        chars = pygame.image.load(ROOT / "assets" / "characters.png").convert()
        title = pygame.image.load(
            ROOT / "assets" / "title_lamplight_dungeons.png"
        ).convert()
        tiles = []
        cw, ch = atlas.get_width() // 4, atlas.get_height() // 4
        for row in range(4):
            for col in range(4):
                tile = atlas.subsurface((col * cw, row * ch, cw, ch)).copy()
                tiles.append(pygame.transform.smoothscale(tile, (180, 180)))
        portraits = {}
        markers = {}
        cw, ch = chars.get_width() // 6, chars.get_height() // 4
        for row, klass in enumerate(CLASSES):
            for col, race in enumerate(RACES):
                image = chars.subsurface((col * cw, row * ch, cw, ch)).copy()
                portraits[(race, klass)] = pygame.transform.smoothscale(image, (150, 150))
                # A round head-and-shoulders token avoids carrying the portrait's
                # square studio backdrop into the dungeon map.
                crop = image.subsurface((cw * 21 // 100, 0, cw * 58 // 100, ch * 62 // 100))
                marker = pygame.transform.smoothscale(crop, (46, 46)).convert_alpha()
                mask = pygame.Surface((46, 46), pygame.SRCALPHA)
                pygame.draw.circle(mask, (255, 255, 255, 255), (23, 23), 22)
                marker.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
                markers[(race, klass)] = marker
        return {"tiles": tiles, "portraits": portraits, "markers": markers, "title": title}

    def init_audio(self):
        try:
            pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=1024)
            audio = ROOT / "assets" / "audio"
            for name in ("click", "step", "hit", "coin", "heal", "danger", "stairs"):
                self.sounds[name] = pygame.mixer.Sound(audio / f"{name}.wav")
            pygame.mixer.music.load(audio / "lamplight_ambient.wav")
            pygame.mixer.music.set_volume(0.22)
            pygame.mixer.music.play(-1)
            self.audio_ok = True
        except (pygame.error, OSError):
            self.audio_ok = False

    def sound(self, name):
        if self.audio_ok and not self.audio_muted and name in self.sounds:
            self.sounds[name].play()

    def add_message(self, message):
        self.messages.append(message)
        self.messages = self.messages[-6:]

    def text(self, value, x, y, color=(232, 232, 217), font=None, center=False):
        image = (font or self.font).render(str(value), True, color)
        rect = image.get_rect()
        if center:
            rect.center = (x, y)
        else:
            rect.topleft = (x, y)
        self.canvas.blit(image, rect)
        return rect

    @staticmethod
    def fit_text(value, font, maximum_width):
        """Ellipsize display text without altering the underlying game data."""
        value = str(value)
        if font.size(value)[0] <= maximum_width:
            return value
        suffix = "…"
        low, high = 0, len(value)
        while low < high:
            middle = (low + high + 1) // 2
            if font.size(value[:middle] + suffix)[0] <= maximum_width:
                low = middle
            else:
                high = middle - 1
        return value[:low] + suffix

    def panel(self, rect, alpha=235, border=(75, 88, 84)):
        surface = pygame.Surface(rect.size, pygame.SRCALPHA)
        surface.fill((10, 14, 17, alpha))
        pygame.draw.rect(surface, border, surface.get_rect(), 2, border_radius=7)
        self.canvas.blit(surface, rect)

    @staticmethod
    def wrap(text, width):
        words, lines, line = text.split(), [], []
        for word in words:
            candidate = " ".join(line + [word])
            if line and len(candidate) > width:
                lines.append(" ".join(line))
                line = []
            line.append(word)
        if line:
            lines.append(" ".join(line))
        return lines

    def new_game(self):
        self.player = new_player(
            self.name_text, self.create_values[0], self.create_values[1],
            self.create_values[2] == "Classic",
        )
        self.enter_town(first=True)
        self.save()

    def enter_town(self, first=False):
        carried = self.player["carried"]
        self.player["bank"] += carried
        self.player["carried"] = 0
        self.player["hp"] = self.player["max_hp"]
        self.player["sp"] = self.player["max_sp"]
        self.rooms = []
        self.combat_enemy = None
        self.state = "town"
        if first:
            self.add_message("The Lamplight Guild records a new adventurer.")
        elif carried:
            self.add_message(f"You return alive and bank {carried} gold.")
        else:
            self.add_message("You return safely to the Lamplight Guild.")
        self.sound("heal")

    def save(self):
        if not self.player or (self.player.get("classic") and self.player.get("dead")):
            return
        data = {
            "version": 1, "player": self.player, "floor_seed": self.floor_seed,
            "rooms": self.rooms, "location": self.location,
            "previous_location": self.previous_location,
            "state": self.state,
        }
        try:
            temporary = SAVE_FILE.with_suffix(".json.tmp")
            temporary.write_text(json.dumps(data, indent=2), encoding="utf-8")
            temporary.replace(SAVE_FILE)
        except OSError:
            self.add_message("The save file could not be written.")

    def load(self):
        if not SAVE_FILE.exists():
            self.add_message("No saved adventurer was found.")
            return False
        try:
            data = json.loads(SAVE_FILE.read_text(encoding="utf-8"))
            if (not isinstance(data, dict) or type(data.get("version")) is not int
                    or data["version"] != 1):
                raise ValueError("Unsupported save")
            self.validate_player(data["player"])
            self.player = data["player"]
            state = data.get("state", "town")
            valid_states = {"town", "room", "combat", "dead", "victory"}
            legacy_states = {"title", "create", "help"}
            if not isinstance(state, str) or state not in valid_states | legacy_states:
                raise ValueError("Invalid saved state")
            if state == "victory" and not self.player.get("won"):
                raise ValueError("Invalid victory state")
            if state == "dead" and self.player.get("classic"):
                raise ValueError("Invalid Classic-mode death save")
            if self.player.get("won"):
                self.rooms = []
                self.combat_enemy = None
                self.state = "victory"
            elif state in ("room", "combat"):
                self.validate_floor(data["rooms"], data["location"], data.get("previous_location", 0))
                self.rooms = data["rooms"]
                self.location = data["location"]
                self.previous_location = data.get("previous_location", self.location)
                self.floor_seed = data.get("floor_seed", 0)
                if type(self.floor_seed) is not int:
                    raise TypeError("Invalid floor seed")
                self.state = "room"
                enemy = self.rooms[self.location].get("enemy")
                if (enemy and self.previous_location != self.location
                        and self.previous_location not in self.rooms[self.location]["exits"].values()):
                    raise ValueError("Invalid retreat position")
                if state == "combat":
                    if not enemy or enemy.get("hp", 0) <= 0:
                        raise ValueError("Missing encounter")
                    self.combat_enemy = enemy
                    self.state = "combat"
                    self.add_message(f"The encounter with {enemy['name']} resumes.")
                elif enemy:
                    self.combat_enemy = enemy
                    self.state = "combat"
                    self.add_message(f"The waiting {enemy['name']} confronts you.")
            else:
                self.enter_town()
            self.add_message(f"Welcome back, {self.player['name']}.")
            return True
        except (KeyError, TypeError, ValueError, IndexError, OSError, json.JSONDecodeError):
            self.player = None
            self.rooms = []
            self.combat_enemy = None
            self.state = "title"
            self.add_message("The save file could not be read.")
            return False

    @staticmethod
    def validate_player(player):
        required = {
            "name", "race", "class", "classic", "level", "xp", "next_xp",
            "hp", "max_hp", "sp", "max_sp", "bank", "carried", "potions",
            "rations", "depth", "deepest", "kills", "stats", "won",
        }
        if not isinstance(player, dict) or not required.issubset(player):
            raise ValueError("Incomplete player")
        if not valid_text(player["name"], 1, 18):
            raise ValueError("Invalid name")
        if player["race"] not in RACES or player["class"] not in CLASSES:
            raise ValueError("Invalid identity")
        if type(player["classic"]) is not bool or type(player["won"]) is not bool:
            raise TypeError("Invalid mode")
        numeric = required - {"name", "race", "class", "classic", "stats", "won"}
        if any(type(player[key]) is not int for key in numeric):
            raise TypeError("Invalid number")
        if not isinstance(player["stats"], dict) or any(
            type(player["stats"].get(key)) is not int for key in RACES["Human"]
        ):
            raise TypeError("Invalid stats")
        if not 1 <= player["depth"] <= 20 or not player["depth"] <= player["deepest"] <= 20:
            raise ValueError("Invalid depth")
        if not 1 <= player["level"] <= 99 or player["next_xp"] < 1:
            raise ValueError("Invalid level")
        if player["max_hp"] < 1 or not 0 < player["hp"] <= player["max_hp"]:
            raise ValueError("Invalid health")
        if player["max_sp"] < 0 or not 0 <= player["sp"] <= player["max_sp"]:
            raise ValueError("Invalid spirit")
        if any(player[key] < 0 for key in ("xp", "bank", "carried", "potions", "rations", "kills")):
            raise ValueError("Invalid inventory")

    @staticmethod
    def validate_floor(rooms, location, previous):
        if not isinstance(rooms, list) or not 5 <= len(rooms) <= 20:
            raise ValueError("Invalid rooms")
        if type(location) is not int or type(previous) is not int:
            raise TypeError("Invalid location")
        if not 0 <= location < len(rooms) or not 0 <= previous < len(rooms):
            raise ValueError("Invalid location")
        if any(not isinstance(room, dict) for room in rooms):
            raise TypeError("Invalid room")
        for index, room in enumerate(rooms):
            if not {"name", "description", "color", "exits", "event", "resolved", "visited", "stairs"}.issubset(room):
                raise ValueError("Incomplete room")
            if not isinstance(room["exits"], dict) or any(key not in DIRECTIONS for key in room["exits"]):
                raise ValueError("Invalid exits")
            if (not valid_text(room["name"], 1, 80)
                    or not valid_text(room["description"], 0, 500, allow_blank=True)):
                raise TypeError("Invalid room text")
            if (not isinstance(room["color"], list) or len(room["color"]) != 3
                    or any(type(channel) is not int or not 0 <= channel <= 255 for channel in room["color"])):
                raise ValueError("Invalid room color")
            if room["event"] not in {"nothing", "chest", "fountain", "shrine", "trap"}:
                raise ValueError("Invalid room event")
            if any(type(room[key]) is not bool for key in ("resolved", "visited", "stairs")):
                raise TypeError("Invalid room state")
            for direction, target in room["exits"].items():
                if type(target) is not int or not 0 <= target < len(rooms):
                    raise ValueError("Invalid exit target")
                if target == index:
                    raise ValueError("Self-looped room link")
                reverse_exits = rooms[target].get("exits")
                if not isinstance(reverse_exits, dict) or reverse_exits.get(OPPOSITE[direction]) != index:
                    raise ValueError("One-way room link")
            if len(set(room["exits"].values())) != len(room["exits"]):
                raise ValueError("Duplicate room link")
            enemy = room.get("enemy")
            if enemy is not None:
                keys = {"name", "hp", "max_hp", "atk", "xp", "gold", "tile"}
                if not isinstance(enemy, dict) or not keys.issubset(enemy):
                    raise ValueError("Invalid enemy")
                if not valid_text(enemy["name"], 1, 80):
                    raise ValueError("Invalid enemy name")
                if any(type(enemy[key]) is not int for key in keys - {"name"}):
                    raise TypeError("Invalid enemy number")
                if enemy["max_hp"] < 1 or not 0 < enemy["hp"] <= enemy["max_hp"]:
                    raise ValueError("Invalid enemy health")
                if enemy["atk"] < 0 or enemy["xp"] < 0 or enemy["gold"] < 0:
                    raise ValueError("Invalid enemy value")
                if not 0 <= enemy["tile"] < 16:
                    raise ValueError("Invalid enemy tile")
        if sum(room["stairs"] for room in rooms) != 1:
            raise ValueError("Invalid staircase count")
        reachable = {0}
        queue = deque([0])
        while queue:
            for target in rooms[queue.popleft()]["exits"].values():
                if target not in reachable:
                    reachable.add(target)
                    queue.append(target)
        if len(reachable) != len(rooms):
            raise ValueError("Disconnected dungeon")
        coordinates = {0: (0, 0)}
        queue = deque([0])
        while queue:
            source = queue.popleft()
            x, y = coordinates[source]
            for direction, target in rooms[source]["exits"].items():
                dx, dy, _ = DIRECTIONS[direction]
                candidate = (x + dx, y + dy)
                if target in coordinates and coordinates[target] != candidate:
                    raise ValueError("Inconsistent room geometry")
                if target not in coordinates:
                    coordinates[target] = candidate
                    queue.append(target)
        if len(set(coordinates.values())) != len(coordinates):
            raise ValueError("Overlapping room geometry")
        if not rooms[0]["visited"] or not rooms[location]["visited"]:
            raise ValueError("Invalid visited rooms")

    def make_floor(self, depth):
        self.floor_seed = random.randrange(1 << 30)
        rng = random.Random(self.floor_seed)
        count = min(7 + depth // 2, 13)
        coords = [(0, 0)]
        exits = [{}]
        while len(coords) < count:
            source = rng.randrange(len(coords))
            directions = list(DIRECTIONS)
            rng.shuffle(directions)
            for direction in directions:
                dx, dy, _ = DIRECTIONS[direction]
                target_coord = (coords[source][0] + dx, coords[source][1] + dy)
                if target_coord not in coords:
                    target = len(coords)
                    coords.append(target_coord)
                    exits.append({OPPOSITE[direction]: source})
                    exits[source][direction] = target
                    break
        for index, (x, y) in enumerate(coords):
            for direction, (dx, dy, _) in DIRECTIONS.items():
                target_coord = (x + dx, y + dy)
                if direction not in exits[index] and target_coord in coords and rng.random() < 0.28:
                    target = coords.index(target_coord)
                    exits[index][direction] = target
                    exits[target][OPPOSITE[direction]] = index

        distances = {0: 0}
        queue = deque([0])
        while queue:
            current = queue.popleft()
            for target in exits[current].values():
                if target not in distances:
                    distances[target] = distances[current] + 1
                    queue.append(target)
        stair_room = max(distances, key=distances.get)
        rooms = []
        for index in range(count):
            name, description, color = rng.choice(ROOMS)
            event = rng.choices(
                ["nothing", "chest", "fountain", "shrine", "trap"],
                weights=[30, 24, 16, 14, 16],
            )[0]
            enemy = None
            if index and (rng.random() < 0.58 or index == stair_room):
                available = [monster for monster in MONSTERS if monster[1] <= depth + 1]
                template = rng.choice(available[-min(4, len(available)):])
                enemy = self.make_enemy(template, depth)
            rooms.append({
                "name": name, "description": description, "color": list(color),
                "exits": exits[index], "event": event if index else "nothing",
                "resolved": index == 0, "visited": index == 0,
                "stairs": index == stair_room, "enemy": enemy,
            })
        if depth in (5, 10, 15, 20):
            template = MONSTERS[min(len(MONSTERS) - 1, depth // 2)]
            boss = self.make_enemy(template, depth)
            boss["name"] = {
                5: "The Rootbound Warden", 10: "The Ember Knight",
                15: "The Glass Abbot", 20: "The Orb Guardian",
            }[depth]
            boss["hp"] = boss["max_hp"] = int(boss["max_hp"] * 1.2)
            boss["xp"] *= 2
            boss["gold"] *= 2
            rooms[stair_room]["enemy"] = boss
        self.rooms = rooms
        self.location = 0
        self.previous_location = 0
        self.combat_enemy = None

    @staticmethod
    def make_enemy(template, depth):
        name, minimum, hp, attack, xp, gold, tile = template
        scale = 1 + max(0, depth - minimum) * 0.04
        return {
            "name": name, "hp": max(1, int(hp * scale)),
            "max_hp": max(1, int(hp * scale)), "atk": max(1, int(attack * scale)),
            "xp": max(1, int(xp * scale)), "gold": max(1, int(gold * scale)),
            "tile": tile,
        }

    def start_floor(self, depth):
        self.player["depth"] = clamp(depth, 1, 20)
        self.player["deepest"] = max(self.player["deepest"], self.player["depth"])
        self.make_floor(self.player["depth"])
        self.state = "room"
        self.last_command = ""
        self.add_message(f"You descend to level {self.player['depth']}, {self.player['depth'] * 50} feet.")
        self.sound("stairs")
        self.save()

    def move_direction(self, direction):
        room = self.rooms[self.location]
        if direction not in room["exits"]:
            self.last_command = direction
            self.add_message(f"There is no passage {DIRECTIONS[direction][2].lower()}.")
            self.sound("click")
            return
        self.previous_location = self.location
        self.location = room["exits"][direction]
        self.rooms[self.location]["visited"] = True
        self.last_command = direction
        self.sound("step")
        self.arrive()
        self.save()

    def arrive(self):
        room = self.rooms[self.location]
        enemy = room.get("enemy")
        if enemy:
            self.combat_enemy = enemy
            self.combat_choice = 0
            self.guard = False
            self.state = "combat"
            self.add_message(f"You have encountered {enemy['name']}!")
            self.sound("danger")
            return
        self.resolve_room_event()

    def resolve_room_event(self):
        room = self.rooms[self.location]
        if room["resolved"]:
            return
        room["resolved"] = True
        event = room["event"]
        depth = self.player["depth"]
        if event == "chest":
            gold = random.randint(8, 18) * depth
            self.player["carried"] += gold
            self.add_message(f"A forgotten coffer holds {gold} gold.")
            self.sound("coin")
        elif event == "fountain":
            amount = min(self.player["max_hp"] - self.player["hp"], 8 + depth)
            self.player["hp"] += amount
            self.add_message(f"Clear water restores {amount} HP.")
            self.sound("heal")
        elif event == "shrine":
            amount = min(self.player["max_sp"] - self.player["sp"], 5 + depth // 2)
            self.player["sp"] += amount
            self.add_message(f"The shrine restores {amount} spirit.")
            self.sound("heal")
        elif event == "trap":
            damage = max(2, depth + random.randint(1, 5))
            self.player["hp"] -= damage
            self.add_message(f"A hidden mechanism strikes for {damage} damage!")
            self.sound("danger")
            if self.player["hp"] <= 0:
                self.die()
        else:
            self.add_message("The chamber is quiet.")

    def descend(self):
        room = self.rooms[self.location]
        if not room["stairs"]:
            self.last_command = "D"
            self.add_message("There is no downward stair here.")
            return
        if room.get("enemy"):
            self.arrive()
            return
        if self.player["depth"] == 20:
            self.player["bank"] += self.player["carried"]
            self.player["carried"] = 0
            self.player["won"] = True
            self.state = "victory"
            self.rooms = []
            self.sound("coin")
            self.save()
        else:
            self.start_floor(self.player["depth"] + 1)

    def return_to_guild(self):
        if self.location != 0:
            self.last_command = "U"
            self.add_message("The upward route is only in the entrance chamber.")
            return
        self.enter_town()
        self.save()

    def rest(self):
        self.last_command = "R"
        if self.player["rations"] <= 0:
            self.add_message("You have no rations left.")
            return
        if self.player["hp"] >= self.player["max_hp"] and self.player["sp"] >= self.player["max_sp"]:
            self.add_message("You are already fully rested.")
            return
        self.player["rations"] -= 1
        hp = min(self.player["max_hp"] - self.player["hp"], 8 + self.player["level"])
        sp = min(self.player["max_sp"] - self.player["sp"], 4 + self.player["level"] // 2)
        self.player["hp"] += hp
        self.player["sp"] += sp
        self.add_message(f"You eat a ration and recover {hp} HP and {sp} spirit.")
        self.sound("heal")
        if random.random() < 0.20:
            candidates = [r for r in self.rooms if r["visited"] and not r.get("enemy")]
            if candidates:
                room = random.choice(candidates)
                template = random.choice([m for m in MONSTERS if m[1] <= self.player["depth"] + 1])
                room["enemy"] = self.make_enemy(template, self.player["depth"])
                if room is self.rooms[self.location]:
                    self.arrive()
        self.save()

    def player_damage(self):
        info = CLASSES[self.player["class"]]
        stat = self.player["stats"][info["main"]]
        return max(
            1,
            info["attack"] + self.player["level"] // 2 + self.player["depth"] // 3
            + (stat - 10) // 2 + random.randint(-2, 3),
        )

    def combat_action(self, index):
        enemy = self.combat_enemy
        if not enemy:
            self.state = "room"
            return
        self.last_command = ("F", "C", "H", "E", "S")[index]
        enemy_turn = True
        if index == 0:
            damage = self.player_damage()
            enemy["hp"] -= damage
            self.add_message(f"You strike {enemy['name']} for {damage}.")
            self.sound("hit")
        elif index == 1:
            klass = self.player["class"]
            if klass == "Knight":
                self.guard = True
                self.add_message("You brace behind your shield.")
            elif klass == "Archer":
                if self.player["sp"] < 2:
                    self.add_message("You lack the focus for an aimed shot.")
                    enemy_turn = False
                else:
                    self.player["sp"] -= 2
                    damage = self.player_damage() + random.randint(4, 8)
                    enemy["hp"] -= damage
                    self.add_message(f"Your aimed shot deals {damage} damage.")
                    self.sound("hit")
            elif klass == "Priest":
                if self.player["sp"] < 3:
                    self.add_message("You lack the spirit to pray.")
                    enemy_turn = False
                elif self.player["hp"] >= self.player["max_hp"]:
                    self.add_message("You are already at full health.")
                    enemy_turn = False
                else:
                    self.player["sp"] -= 3
                    amount = min(9 + self.player["level"], self.player["max_hp"] - self.player["hp"])
                    self.player["hp"] += amount
                    self.add_message(f"Your prayer restores {amount} HP.")
                    self.sound("heal")
            else:
                if self.player["sp"] < 3:
                    self.add_message("You lack the mana for an arcane bolt.")
                    enemy_turn = False
                else:
                    self.player["sp"] -= 3
                    damage = (
                        10 + self.player["level"] + self.player["depth"] // 2
                        + random.randint(2, 8)
                    )
                    enemy["hp"] -= damage
                    self.add_message(f"Your arcane bolt deals {damage} damage.")
                    self.sound("hit")
        elif index == 2:
            if self.player["potions"] <= 0:
                self.add_message("You have no healing potions.")
                enemy_turn = False
            elif self.player["hp"] >= self.player["max_hp"]:
                self.add_message("You are already at full health.")
                enemy_turn = False
            else:
                self.player["potions"] -= 1
                amount = min(random.randint(18, 30), self.player["max_hp"] - self.player["hp"])
                self.player["hp"] += amount
                self.add_message(f"The potion restores {amount} HP.")
                self.sound("heal")
        elif index == 3:
            chance = clamp(0.38 + (self.player["stats"]["dex"] - 10) * 0.025, 0.15, 0.75)
            if random.random() < chance:
                old_location = self.location
                retreat = self.previous_location
                if retreat == old_location:
                    exits = list(self.rooms[old_location]["exits"].values())
                    safe_exits = [target for target in exits if not self.rooms[target].get("enemy")]
                    retreat = (safe_exits or exits)[0]
                self.location = retreat
                self.previous_location = old_location
                self.rooms[self.location]["visited"] = True
                self.state = "room"
                self.combat_enemy = None
                self.add_message(f"You evade {enemy['name']} and retreat.")
                self.sound("step")
                if self.rooms[self.location].get("enemy"):
                    self.arrive()
                self.save()
                return
            self.add_message("You fail to escape!")
        else:
            self.add_message("You stay and watch your opponent.")
        if enemy["hp"] <= 0:
            self.win_combat()
            return
        if enemy_turn:
            self.enemy_attack()
        self.save()

    def enemy_attack(self):
        enemy = self.combat_enemy
        armor = CLASSES[self.player["class"]]["armor"] + self.player["level"] // 4
        damage = max(1, enemy["atk"] + random.randint(-2, 3) - armor)
        if self.guard:
            damage //= 2
            self.guard = False
        self.player["hp"] -= damage
        self.add_message(f"{enemy['name']} hits you for {damage}.")
        self.sound("hit")
        if self.player["hp"] <= 0:
            self.die()

    def win_combat(self):
        enemy = self.combat_enemy
        self.player["xp"] += enemy["xp"]
        self.player["carried"] += enemy["gold"]
        self.player["kills"] += 1
        self.add_message(f"You defeat {enemy['name']} and take {enemy['gold']} gold.")
        self.rooms[self.location]["enemy"] = None
        self.combat_enemy = None
        while self.player["xp"] >= self.player["next_xp"] and self.player["level"] < 99:
            self.player["level"] += 1
            self.player["next_xp"] *= 2
            hp_gain = random.randint(5, 9) + max(0, self.player["stats"]["con"] - 10) // 2
            sp_gain = 4 if self.player["class"] in ("Priest", "Mage") else 3
            self.player["max_hp"] += hp_gain
            self.player["max_sp"] += sp_gain
            self.player["hp"] = self.player["max_hp"]
            self.player["sp"] = self.player["max_sp"]
            self.add_message(f"You advance to level {self.player['level']}!")
        self.state = "room"
        self.resolve_room_event()
        self.save()

    def die(self):
        lost = self.player["carried"]
        self.player["carried"] = 0
        self.state = "dead"
        if self.player["classic"]:
            self.player["dead"] = True
            try:
                SAVE_FILE.unlink(missing_ok=True)
            except OSError:
                pass
        else:
            self.player["hp"] = self.player["max_hp"]
            self.player["sp"] = self.player["max_sp"]
            self.rooms = []
            self.combat_enemy = None
            self.save()
        self.add_message(f"The dungeon claims you. {lost} carried gold is lost.")
        self.sound("danger")

    def buy(self, item):
        costs = {"potion": (35, "potions"), "ration": (15, "rations")}
        cost, key = costs[item]
        if self.player["bank"] < cost:
            self.add_message("You cannot afford that.")
            return
        self.player["bank"] -= cost
        self.player[key] += 1
        self.add_message(f"You purchase one {item} for {cost} gold.")
        self.sound("coin")
        self.save()

    def handle_event(self, event):
        if event.type == pygame.QUIT:
            if self.state in ("town", "room", "combat"):
                self.save()
            self.running = False
            return
        if event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
            self.toggle_fullscreen()
            return
        if self.state == "intro":
            if (event.type == pygame.KEYDOWN or
                    (event.type == pygame.MOUSEBUTTONDOWN and event.button == 1)):
                self.sound("click")
                self.state = "title"
            return
        if event.type in (pygame.MOUSEMOTION, pygame.MOUSEBUTTONDOWN):
            self.handle_mouse(event)
            return
        if event.type != pygame.KEYDOWN:
            return
        if event.key == pygame.K_m and not (self.state == "create" and self.create_row == 0):
            self.audio_muted = not self.audio_muted
            if self.audio_ok:
                pygame.mixer.music.pause() if self.audio_muted else pygame.mixer.music.unpause()
            return
        handlers = {
            "title": self.handle_title, "create": self.handle_create,
            "town": self.handle_town, "room": self.handle_room,
            "combat": self.handle_combat,
        }
        if self.state in handlers:
            handlers[self.state](event)
        elif self.state in ("help", "dead", "victory") and event.key in (pygame.K_RETURN, pygame.K_ESCAPE):
            self.state = "title"

    def toggle_fullscreen(self):
        self.fullscreen = not self.fullscreen
        flags = pygame.FULLSCREEN if self.fullscreen else pygame.RESIZABLE
        self.window = pygame.display.set_mode((0, 0) if self.fullscreen else (WIDTH, HEIGHT), flags)

    def mouse_position(self, event):
        ww, wh = self.window.get_size()
        scale = max(1 / max(WIDTH, HEIGHT), min(ww / WIDTH, wh / HEIGHT))
        ox, oy = (ww - WIDTH * scale) / 2, (wh - HEIGHT * scale) / 2
        return ((event.pos[0] - ox) / scale, (event.pos[1] - oy) / scale)

    def handle_mouse(self, event):
        x, y = self.mouse_position(event)
        clicked = event.type == pygame.MOUSEBUTTONDOWN and event.button == 1
        if self.state == "title":
            for index in range(4):
                if pygame.Rect(60, 345 + index * 48, 390, 44).collidepoint(x, y):
                    self.title_choice = index
                    if clicked:
                        self.activate_title()
                    return
        elif self.state == "create" and clicked:
            for index in range(5):
                if pygame.Rect(150, 150 + index * 82, 650, 62).collidepoint(x, y):
                    self.create_row = index
                    if index in (1, 2, 3):
                        self.change_create(1)
                    elif index == 4:
                        self.new_game()
                    return
        elif self.state == "town" and clicked:
            buttons = [
                (pygame.Rect(370, 300, 600, 52), lambda: self.start_floor(self.player["deepest"])),
                (pygame.Rect(370, 365, 600, 52), lambda: self.buy("potion")),
                (pygame.Rect(370, 430, 600, 52), lambda: self.buy("ration")),
                (pygame.Rect(370, 495, 600, 52), self.return_title),
            ]
            for rect, action in buttons:
                if rect.collidepoint(x, y):
                    action()
                    return
        elif self.state == "room" and clicked:
            for direction, target in self.rooms[self.location]["exits"].items():
                hitbox = self.map_hitboxes.get(target)
                if hitbox and hitbox.collidepoint(x, y):
                    self.move_direction(direction)
                    return
            for command, hitbox in self.room_command_hitboxes.items():
                if hitbox.collidepoint(x, y):
                    if command in DIRECTIONS:
                        self.move_direction(command)
                    elif command == "D":
                        self.descend()
                    elif command == "U":
                        self.return_to_guild()
                    elif command == "R":
                        self.rest()
                    return
        elif self.state == "combat":
            for index, hitbox in self.combat_hitboxes.items():
                if hitbox.collidepoint(x, y):
                    self.combat_choice = index
                    if clicked:
                        self.combat_action(index)
                    return
        elif self.state in ("help", "dead", "victory") and clicked:
            self.state = "title"

    def return_title(self):
        self.save()
        self.state = "title"

    def activate_title(self):
        self.sound("click")
        if self.title_choice == 0:
            self.state = "create"
        elif self.title_choice == 1:
            self.load()
        elif self.title_choice == 2:
            self.state = "help"
        else:
            self.running = False

    def handle_title(self, event):
        if event.key in (pygame.K_UP, pygame.K_w):
            self.title_choice = (self.title_choice - 1) % 4
        elif event.key in (pygame.K_DOWN, pygame.K_s):
            self.title_choice = (self.title_choice + 1) % 4
        elif event.key == pygame.K_RETURN:
            self.activate_title()

    def change_create(self, direction):
        if self.create_row == 1:
            values = list(RACES)
            self.create_values[0] = values[(values.index(self.create_values[0]) + direction) % len(values)]
        elif self.create_row == 2:
            values = list(CLASSES)
            self.create_values[1] = values[(values.index(self.create_values[1]) + direction) % len(values)]
        elif self.create_row == 3:
            self.create_values[2] = "Classic" if self.create_values[2] == "Adventure" else "Adventure"

    def handle_create(self, event):
        if event.key == pygame.K_ESCAPE:
            self.state = "title"
        elif self.create_row == 0 and event.key == pygame.K_BACKSPACE:
            self.name_text = self.name_text[:-1]
        elif self.create_row == 0 and event.unicode.isprintable() and event.unicode not in "\r\n\t" and len(self.name_text) < 18:
            self.name_text += event.unicode
        elif event.key in (pygame.K_UP, pygame.K_w):
            self.create_row = (self.create_row - 1) % 5
        elif event.key in (pygame.K_DOWN, pygame.K_s):
            self.create_row = (self.create_row + 1) % 5
        elif event.key in (pygame.K_LEFT, pygame.K_a):
            self.change_create(-1)
        elif event.key in (pygame.K_RIGHT, pygame.K_d):
            self.change_create(1)
        elif event.key == pygame.K_RETURN and self.create_row == 4:
            self.new_game()

    def handle_town(self, event):
        if event.key == pygame.K_1:
            self.start_floor(self.player["deepest"])
        elif event.key == pygame.K_2:
            self.buy("potion")
        elif event.key == pygame.K_3:
            self.buy("ration")
        elif event.key in (pygame.K_q, pygame.K_ESCAPE):
            self.return_title()

    def handle_room(self, event):
        typed = event.unicode.upper()
        if typed in DIRECTIONS:
            self.move_direction(typed)
        elif typed == "D":
            self.last_command = "D"
            self.descend()
            self.save()
        elif typed == "U":
            self.last_command = "U"
            self.return_to_guild()
        elif typed == "R":
            self.rest()
        elif typed == "L":
            self.last_command = "L"
            self.add_message(self.rooms[self.location]["description"])
        elif event.key == pygame.K_F5:
            self.save()
            self.add_message("Game saved.")
        elif event.key == pygame.K_ESCAPE:
            self.save()
            self.state = "title"

    def handle_combat(self, event):
        direct = {"F": 0, "C": 1, "H": 2, "E": 3, "S": 4}
        typed = event.unicode.upper()
        if event.key == pygame.K_UP:
            self.combat_choice = (self.combat_choice - 1) % 5
        elif event.key == pygame.K_DOWN:
            self.combat_choice = (self.combat_choice + 1) % 5
        elif typed in direct:
            self.combat_action(direct[typed])
        elif pygame.K_1 <= event.key <= pygame.K_5:
            self.combat_action(event.key - pygame.K_1)
        elif event.key == pygame.K_RETURN:
            self.combat_action(self.combat_choice)

    def draw_background(self):
        bg = pygame.transform.smoothscale(self.assets["title"], (WIDTH, HEIGHT))
        self.canvas.blit(bg, (0, 0))
        shade = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 145))
        self.canvas.blit(shade, (0, 0))

    def draw_title(self):
        self.draw_background()
        self.text("LAMPLIGHT", 58, 76, (250, 205, 91), self.title_font)
        self.text("DUNGEONS", 62, 150, (240, 239, 224), self.title_font)
        self.text("A room-driven mainframe expedition", 67, 243, (190, 205, 200), self.font)
        self.panel(pygame.Rect(45, 325, 430, 228), 218)
        options = ("New adventurer", "Continue", "Instructions", "Quit")
        for index, option in enumerate(options):
            color = (255, 207, 87) if index == self.title_choice else (232, 232, 220)
            self.text(("> " if index == self.title_choice else "  ") + option, 76, 357 + index * 48, color, self.mono)
        status = "Audio ON" if self.audio_ok and not self.audio_muted else ("Audio muted" if self.audio_ok else "Audio unavailable")
        self.text(f"F11 FULLSCREEN  ·  M {status.upper()}  ·  VERSION {VERSION}", 48, 680, (175, 185, 180), self.mono_small)

    def draw_intro(self):
        elapsed = pygame.time.get_ticks() - self.intro_started
        if elapsed >= 9000:
            self.state = "title"
            self.draw_title()
            return
        self.draw_background()
        shade = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 92))
        self.canvas.blit(shade, (0, 0))
        pages = (
            ("THE GUILD'S LAMPS END HERE.",
             "Beyond them, twenty forgotten levels descend into darkness."),
            ("EVERY CHAMBER IS A CHOICE.",
             "Travel by passage. Face what appears. Carry what you can."),
            ("THE ORB WAITS BELOW.",
             "Choose a name, enter the dungeon, and bring back the light."),
        )
        heading, line = pages[min(2, elapsed // 3000)]
        phase = elapsed % 3000
        alpha = min(255, phase * 255 // 500, (3000 - phase) * 255 // 500)
        color = (255 * alpha // 255, 207 * alpha // 255, 87 * alpha // 255)
        body = (225 * alpha // 255, 228 * alpha // 255, 216 * alpha // 255)
        self.text(heading, 58, 118, color, self.mono_big)
        for index, wrapped in enumerate(self.wrap(line, 46)):
            self.text(wrapped, 62, 184 + index * 34, body, self.mono_small)
        self.text("PRESS ANY KEY TO SKIP", 62, 650, (142, 154, 148), self.mono_small)

    def draw_create(self):
        self.draw_background()
        self.text("CREATE AN ADVENTURER", WIDTH // 2, 62, (250, 205, 91), self.mono_big, True)
        self.panel(pygame.Rect(115, 125, 735, 465))
        labels = [
            ("NAME", self.name_text), ("SPECIES", self.create_values[0]),
            ("CLASS", self.create_values[1]), ("FATE", self.create_values[2]),
            ("BEGIN", "Enter the Lamplight Guild"),
        ]
        for index, (label, value) in enumerate(labels):
            y = 171 + index * 82
            active = index == self.create_row
            color = (255, 207, 87) if active else (232, 232, 220)
            self.text((">" if active else " ") + label, 155, y, color, self.mono)
            self.text(value + ("_" if active and index == 0 else ""), 365, y, color, self.mono)
        race, klass = self.create_values[:2]
        self.panel(pygame.Rect(885, 125, 300, 465))
        self.canvas.blit(self.assets["portraits"][(race, klass)], (960, 150))
        preview = new_player(self.name_text, race, klass, self.create_values[2] == "Classic")
        self.text(f"{race.upper()} {klass.upper()}", 1035, 325, (255, 207, 87), self.mono, True)
        for index, key in enumerate(("str", "int", "wis", "dex", "con", "cha")):
            self.text(f"{key.upper():3} {preview['stats'][key]:2}", 925 + (index % 2) * 130, 365 + (index // 2) * 32, font=self.mono_small)
        self.text(f"HP {preview['max_hp']}   SP {preview['max_sp']}", 1035, 475, (150, 225, 165), self.mono, True)
        mode = "DEATH ERASES THE SAVE" if preview["classic"] else "DEFEAT RETURNS TO TOWN"
        self.text(mode, 1035, 530, (205, 175, 120), self.mono_small, True)
        self.text("ARROWS CHOOSE  ·  ENTER BEGINS  ·  ESC RETURNS", WIDTH // 2, 655, (185, 195, 190), self.mono_small, True)

    def draw_sheet(self):
        p = self.player
        name = p["name"].upper()
        name_line = self.fit_text(f"NAME     {name}", self.mono, 390)
        self.text(name_line, 18, 18, (238, 238, 222), self.mono)
        self.text(f"[{p['race'].upper()} {p['class'].upper()}]", 18, 49,
                  (105, 225, 220), self.mono_small)
        self.text("DUNGEON  LAMPLIGHT DEPTHS", 18, 76, (190, 198, 187), self.mono_small)
        rows = (
            ("LEVEL", p["level"], (255, 207, 87)),
            ("EXP", p["xp"], (224, 224, 210)),
            ("GOLD", p["carried"], (255, 195, 90)),
            ("HIT PTS", f"{p['hp']} / {p['max_hp']}", (140, 235, 155)),
            ("SPIRIT", f"{p['sp']} / {p['max_sp']}", (130, 190, 245)),
            ("DEPTH", f"{p['depth'] * 50} FT", (224, 224, 210)),
            ("BANK", p["bank"], (180, 220, 185)),
        )
        for index, (label, value, color) in enumerate(rows):
            line = self.fit_text(f"{label:<8} {value}", self.mono_small, 240)
            self.text(line, 18, 110 + index * 29, color, self.mono_small)
        for index, key in enumerate(("str", "int", "wis", "con", "dex", "cha")):
            line = self.fit_text(f"{key.upper():3} {p['stats'][key]:>2}", self.mono_small, 135)
            self.text(line, 275, 110 + index * 29, (224, 224, 210), self.mono_small)
        inventory = self.fit_text(
            f"POTIONS  {p['potions']}    RATIONS  {p['rations']}", self.mono_small, 390
        )
        self.text(inventory, 18, 328, (190, 198, 187), self.mono_small)
        fate = "CLASSIC" if p["classic"] else "ADVENTURE"
        self.text(f"FATE     {fate}", 18, 357, (175, 178, 168), self.mono_small)

    def bar(self, x, y, width, ratio, color):
        pygame.draw.rect(self.canvas, (42, 44, 45), (x, y, width, 12), border_radius=4)
        pygame.draw.rect(self.canvas, color, (x, y, int(width * clamp(ratio, 0, 1)), 12), border_radius=4)

    def room_map_positions(self):
        """Reconstruct the procedural floor's compass layout from its exits."""
        positions = {0: (0, 0)}
        queue = deque([0])
        while queue:
            source = queue.popleft()
            x, y = positions[source]
            for direction, target in self.rooms[source]["exits"].items():
                dx, dy, _ = DIRECTIONS[direction]
                if target not in positions:
                    positions[target] = (x + dx, y + dy)
                    queue.append(target)
        return positions

    def dungeon_geometry(self):
        """Build stable rectangular chambers and bent corridors for this floor."""
        positions = self.room_map_positions()
        rng = random.Random(self.floor_seed ^ 0x4C414D50)
        centers = {}
        room_cells = {}
        tile_owner = {}
        for index in range(len(self.rooms)):
            map_x, map_y = positions[index]
            center = (map_x * 16 + rng.randint(-2, 2), map_y * 12 + rng.randint(-1, 1))
            centers[index] = center
            width = rng.choice((7, 9, 11))
            height = rng.choice((5, 7))
            left, top = center[0] - width // 2, center[1] - height // 2
            cells = {
                (x, y)
                for x in range(left, left + width)
                for y in range(top, top + height)
            }
            room_cells[index] = cells
            for cell in cells:
                tile_owner[cell] = index

        def segment(path, start, end):
            x, y = start
            if not path or path[-1] != (x, y):
                path.append((x, y))
            while (x, y) != end:
                if x != end[0]:
                    x += 1 if end[0] > x else -1
                else:
                    y += 1 if end[1] > y else -1
                if path[-1] != (x, y):
                    path.append((x, y))

        corridors = {}
        for source, room in enumerate(self.rooms):
            for target in room["exits"].values():
                link = tuple(sorted((source, target)))
                if link in corridors:
                    continue
                start, end = centers[link[0]], centers[link[1]]
                path = []
                if abs(end[0] - start[0]) >= abs(end[1] - start[1]):
                    middle = (round((start[0] + end[0]) / 2), start[1])
                    turn = (middle[0], end[1])
                else:
                    middle = (start[0], round((start[1] + end[1]) / 2))
                    turn = (end[0], middle[1])
                segment(path, start, middle)
                segment(path, middle, turn)
                segment(path, turn, end)
                corridors[link] = path
        return centers, room_cells, tile_owner, corridors

    def draw_scene(self):
        rect = pygame.Rect(430, 22, 825, 466)
        self.map_hitboxes = {}

        centers, room_cells, tile_owner, corridors = self.dungeon_geometry()
        visited = {index for index, room in enumerate(self.rooms) if room["visited"]}
        visible_floor = set().union(*(room_cells[index] for index in visited))
        route_endpoints = {}
        for link, route in corridors.items():
            first, second = link
            if first in visited and second in visited:
                visible_floor.update(route)
            elif first in visited or second in visited:
                known, unknown = (first, second) if first in visited else (second, first)
                oriented = route if link[0] == known else list(reversed(route))
                room_edge = max(
                    offset
                    for offset, cell in enumerate(oriented)
                    if cell in room_cells[known]
                )
                stub = oriented[:min(len(oriented), room_edge + 5)]
                visible_floor.update(stub)
                route_endpoints[(known, unknown)] = stub[-1]

        wall_cells = {
            (x + dx, y + dy)
            for x, y in visible_floor
            for dx in (-1, 0, 1)
            for dy in (-1, 0, 1)
            if (dx or dy) and (x + dx, y + dy) not in visible_floor
        }
        shown_cells = visible_floor | wall_cells
        min_x = min(x for x, _ in shown_cells)
        max_x = max(x for x, _ in shown_cells)
        min_y = min(y for _, y in shown_cells)
        max_y = max(y for _, y in shown_cells)
        map_rect = rect.inflate(-20, -20)
        tile = max(3, min(14, map_rect.width // (max_x - min_x + 1),
                          map_rect.height // (max_y - min_y + 1)))
        drawn_width = (max_x - min_x + 1) * tile
        drawn_height = (max_y - min_y + 1) * tile
        origin_x = map_rect.centerx - drawn_width // 2 - min_x * tile
        origin_y = map_rect.centery - drawn_height // 2 - min_y * tile

        def tile_rect(cell):
            return pygame.Rect(origin_x + cell[0] * tile, origin_y + cell[1] * tile, tile, tile)

        for cell in wall_cells:
            square = tile_rect(cell)
            pygame.draw.rect(self.canvas, (132, 142, 132), square)
            if tile >= 5:
                pygame.draw.rect(self.canvas, (55, 61, 58), square, 1)
        for cell in visible_floor:
            owner = tile_owner.get(cell)
            if owner is None or owner not in visited:
                color = (14, 20, 18)
            else:
                room_color = self.rooms[owner]["color"]
                color = tuple(max(12, channel - 22) for channel in room_color)
            square = tile_rect(cell)
            pygame.draw.rect(self.canvas, color, square)
            if tile >= 6:
                pygame.draw.rect(self.canvas, (25, 30, 28), square, 1)

        adjacent = self.rooms[self.location]["exits"].values()
        for index in adjacent:
            if index in visited:
                cells = room_cells[index]
                left = min(tile_rect(cell).left for cell in cells)
                top = min(tile_rect(cell).top for cell in cells)
                right = max(tile_rect(cell).right for cell in cells)
                bottom = max(tile_rect(cell).bottom for cell in cells)
                self.map_hitboxes[index] = pygame.Rect(left, top, right - left, bottom - top)
            elif (self.location, index) in route_endpoints:
                route_endpoint = route_endpoints[(self.location, index)]
                endpoint = tile_rect(route_endpoint).inflate(tile * 4, tile * 4)
                self.map_hitboxes[index] = endpoint
                self.text("+", *tile_rect(route_endpoint).center, (255, 207, 87),
                          self.tiny, True)

        marker_font = self.mono_small if tile >= 5 else self.tiny
        for index in visited:
            x, y = centers[index]
            center = tile_rect((x, y)).center
            if index == self.location:
                marker = self.assets["markers"][(self.player["race"], self.player["class"])]
                marker_size = max(12, min(24, tile * 2))
                marker = pygame.transform.smoothscale(marker, (marker_size, marker_size))
                pygame.draw.circle(self.canvas, (19, 24, 21), center, marker_size // 2 + 2)
                self.canvas.blit(marker, marker.get_rect(center=center))
                pygame.draw.circle(self.canvas, (255, 215, 92), center, marker_size // 2 + 1, 1)
            elif self.rooms[index].get("enemy"):
                self.text("!", *center, (240, 83, 66), marker_font, True)
            elif self.rooms[index]["stairs"]:
                self.text("▼", *center, (255, 207, 87), marker_font, True)
            elif index == 0:
                self.text("▲", *center, (135, 225, 190), marker_font, True)

    def draw_room(self):
        self.canvas.fill((4, 7, 9))
        self.draw_sheet()
        room = self.rooms[self.location]
        self.draw_scene()
        self.room_command_hitboxes = {}
        room_heading = self.fit_text(f"This is {room['name']}.", self.mono_small, 700)
        self.text(room_heading, 18, 493, (238, 238, 222), self.mono_small)
        event = "CLEARED" if room["resolved"] else room["event"].upper()
        stair = "DOWN STAIR" if room["stairs"] else "NO STAIR"
        self.text(f"EVENT {event}  ·  {stair}", 760, 493, (170, 182, 171), self.mono_small)
        description = self.fit_text(room["description"], self.mono_small, 1220)
        self.text(description, 18, 521, (205, 210, 199), self.mono_small)
        for index, message in enumerate(self.messages[-2:]):
            message = self.fit_text(message, self.mono_small, 1220)
            self.text(message, 18, 553 + index * 26, (190, 205, 192), self.mono_small)

        self.text("Move>", 18, 614, (238, 238, 222), self.mono)
        self.text("_", 84, 614, (255, 207, 87), self.mono)
        x = 135
        for direction in DIRECTIONS:
            if direction not in room["exits"]:
                continue
            label = f"({direction}){DIRECTIONS[direction][2][1:]}"
            hitbox = self.text(label, x, 617, (255, 207, 87), self.mono_small)
            self.room_command_hitboxes[direction] = hitbox.inflate(12, 10)
            x += hitbox.width + 22

        commands = (
            ("D", "(D)own", room["stairs"]),
            ("U", "(U)p to guild", self.location == 0),
            ("R", "(R)est", True),
        )
        x = 18
        for command, label, enabled in commands:
            hitbox = self.text(label, x, 674, (170, 195, 180) if enabled else (72, 78, 75),
                               self.mono_small)
            if enabled:
                self.room_command_hitboxes[command] = hitbox.inflate(12, 10)
            x += hitbox.width + 28
        self.text("(L)ook   F5 Save   Esc Title   F11 Fullscreen", 700, 674,
                  (118, 128, 122), self.tiny)

    def draw_combat(self):
        self.canvas.fill((5, 7, 9))
        self.draw_sheet()
        self.draw_scene()
        enemy = self.combat_enemy
        self.combat_hitboxes = {}
        encounter = self.fit_text(f"You have encountered {enemy['name']}.", self.mono_small, 700)
        latest = self.fit_text(self.messages[-1], self.mono_small, 700)
        self.text(encounter, 18, 493,
                  (245, 205, 112), self.mono_small)
        self.text(latest, 18, 523, (215, 215, 201), self.mono_small)
        self.text(f"Enemy hit points: {enemy['hp']} / {enemy['max_hp']}", 760, 493,
                  (230, 105, 88), self.mono_small)
        self.bar(760, 521, 250, enemy["hp"] / enemy["max_hp"], (165, 50, 43))
        monster = pygame.transform.smoothscale(self.assets["tiles"][enemy["tile"]], (82, 82))
        self.canvas.blit(monster, monster.get_rect(center=(1165, 545)))
        skill = CLASSES[self.player["class"]]["skill"]
        self.text("Do you wish to:", 18, 574, (238, 238, 222), self.mono_small)
        options = ("(F)ight", f"(C) {skill}", f"(H)eal [{self.player['potions']}]", "(E)vade", "(S)tay")
        x = 18
        for index, option in enumerate(options):
            color = (255, 207, 87) if index == self.combat_choice else (230, 230, 217)
            label = ("> " if index == self.combat_choice else "  ") + option
            hitbox = self.text(label, x, 611, color, self.mono_small)
            self.combat_hitboxes[index] = hitbox.inflate(10, 10)
            x += hitbox.width + 18
        self.text("Combat>", 18, 665, (238, 238, 222), self.mono)
        self.text("_", 112, 665, (255, 207, 87), self.mono)
        self.text("1–5 or arrows select   Enter acts   F11 Fullscreen", 700, 674,
                  (118, 128, 122), self.tiny)

    def draw_town(self):
        self.draw_background()
        self.text("THE LAMPLIGHT GUILD", WIDTH // 2, 66, (250, 205, 91), self.large, True)
        self.panel(pygame.Rect(130, 120, 1020, 490), 235)
        portrait = self.assets["portraits"][(self.player["race"], self.player["class"])]
        self.canvas.blit(portrait, (175, 170))
        self.text(f"{self.player['name']}, {self.player['race']} {self.player['class']}", 375, 165, font=self.large)
        self.text(
            f"Level {self.player['level']}  ·  Deepest descent {self.player['deepest'] * 50} feet  ·  Banked gold {self.player['bank']}",
            377, 230, (190, 220, 195), self.font,
        )
        options = (
            "[1] Enter the dungeon", "[2] Buy healing potion — 35 gold",
            "[3] Buy ration — 15 gold", "[Q] Save and return to title",
        )
        for index, option in enumerate(options):
            self.text(option, 400, 315 + index * 65, (255, 207, 87) if index == 0 else (232, 232, 220), self.mono)
        self.text(self.messages[-1], WIDTH // 2, 652, (205, 215, 205), self.mono_small, True)

    def draw_help(self):
        self.canvas.fill((8, 12, 15))
        self.text("HOW TO PLAY", WIDTH // 2, 50, (250, 205, 91), self.large, True)
        self.panel(pygame.Rect(115, 95, 1050, 540))
        lines = [
            "Lamplight Dungeons uses rooms, not tile-by-tile movement.",
            "Type N, S, E, or W to take an available passage.",
            "The entire scene changes when you enter the next location.",
            "Enemies appear immediately and open a turn-based encounter.",
            "",
            "ROOM COMMANDS", "N/S/E/W  Travel     D  Descend     U  Return to guild",
            "R  Rest with a ration     L  Look again     F5  Save     Esc  Title",
            "",
            "ENCOUNTER COMMANDS", "F  Fight     C  Class skill     H  Heal     E  Evade     S  Stay",
            "Arrow keys and Enter, number keys 1–5, and the mouse also work.",
            "",
            "Carried gold is unsafe until you return to the guild.",
            "Adventure mode rescues a defeated hero. Classic mode erases the save.",
            "Reach level 20, defeat the Orb Guardian, and descend once more to win.",
            "", "Press Enter or Esc to return.",
        ]
        for index, line in enumerate(lines):
            color = (255, 207, 87) if line in ("ROOM COMMANDS", "ENCOUNTER COMMANDS") else (224, 226, 215)
            self.text(line, 165, 123 + index * 28, color, self.mono_small)

    def draw_dead(self):
        self.draw_background()
        self.text("THE DUNGEON CLAIMS YOU", WIDTH // 2, 180, (225, 82, 67), self.large, True)
        classic = self.player and self.player.get("classic")
        line = "Your adventurer and save are gone." if classic else "The guild retrieves you, but your carried treasure is lost."
        self.text(line, WIDTH // 2, 285, font=self.font, center=True)
        self.text("PRESS ENTER", WIDTH // 2, 400, (255, 207, 87), self.mono, True)

    def draw_victory(self):
        self.draw_background()
        self.text("THE ORB OF LAMPLIGHT", WIDTH // 2, 150, (250, 205, 91), self.title_font, True)
        self.text("The twentieth dungeon has yielded. Your name enters the guild's eternal record.", WIDTH // 2, 285, center=True)
        self.text(
            f"{self.player['name']} returns with {self.player['kills']} victories and {self.player['bank']} banked gold.",
            WIDTH // 2, 335, (180, 225, 190), self.font, True,
        )
        self.text("PRESS ENTER", WIDTH // 2, 450, (255, 207, 87), self.mono, True)

    def draw(self):
        {
            "intro": self.draw_intro, "title": self.draw_title,
            "create": self.draw_create, "town": self.draw_town,
            "room": self.draw_room, "combat": self.draw_combat, "help": self.draw_help,
            "dead": self.draw_dead, "victory": self.draw_victory,
        }[self.state]()
        ww, wh = self.window.get_size()
        scale = min(ww / WIDTH, wh / HEIGHT)
        size = (max(1, round(WIDTH * scale)), max(1, round(HEIGHT * scale)))
        target = pygame.transform.smoothscale(self.canvas, size)
        self.window.fill((0, 0, 0))
        self.window.blit(target, ((ww - size[0]) // 2, (wh - size[1]) // 2))
        pygame.display.flip()

    def run(self):
        while self.running:
            for event in pygame.event.get():
                self.handle_event(event)
            self.draw()
            self.clock.tick(60)
        pygame.quit()


if __name__ == "__main__":
    Game().run()
