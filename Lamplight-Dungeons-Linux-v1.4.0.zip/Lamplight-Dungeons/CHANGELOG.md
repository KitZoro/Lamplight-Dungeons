# Changelog

## 1.4.0

- Added original Lamplight Dungeons title artwork built around its room-and-passage exploration style.
- Added a three-part cinematic opening that establishes the guild, the twenty-level descent, and the Orb.
- Made the opening skippable with any key or a left click and allowed F11 fullscreen toggling throughout it.
- Reworked the title screen around the new dungeon-specific artwork while retaining exact, code-rendered menu text.

## 1.3.1

- Fixed legal long character names overlapping the race and class identity line.
- Fixed unexplored-room click targets sometimes attaching to the wrong passage when several visited rooms bordered the same destination.
- Safely shortened unusually long room, enemy, message, statistic, and inventory text before it could obscure nearby information.
- Kept the compact DND-style character sheet readable after the added identity line.

## 1.3.0

- Rebuilt the play screen around the layout and interaction rhythm of Daniel Lawrence's DND.
- Removed the exploration dashboard, framed map widget, oversized headings, and large command buttons.
- Placed compact character statistics, the dungeon, messages, and the active prompt on one terminal-like playfield.
- Kept the dungeon map visible when an encounter begins and moved round-by-round combat choices beneath it.
- Added restrained graphical wall, floor, passage, player, monster, and status treatments without losing the sparse mainframe composition.
- Retained mouse navigation, fullscreen scaling, sound, saves, furry species/classes, and modern accessibility conveniences.

## 1.2.0

- Replaced the room-node diagram with continuous tiled dungeon geometry inspired by the DEC DND display.
- Added differently sized rectangular chambers, enclosing walls, bent connecting corridors, and open passages into darkness.
- Made the discovered map expand as the adventurer explores while preserving stable geometry across saves.
- Kept the compact race/class character token inside the current chamber and retained clickable passage navigation.
- Preserved room-to-room N/S/E/W movement and immediate turn-based encounter screens.

## 1.1.0

- Rebuilt exploration around a persistent overhead dungeon map rather than a decorative room view.
- Added visible corridors, visited rooms, adjacent unexplored rooms, and markers for the entrance, stairs, and known enemies.
- Made every adjacent room on the map directly clickable while retaining N/S/E/W controls.
- Added a compact race/class player token that blends into the current map room instead of covering the scene with a square portrait.
- Added explicit room-event and staircase information beside the room description.
- Replaced the misleading retained command text with a clear compass-command prompt.
- Rejected inconsistent or overlapping saved-room geometry before drawing the map.

## 1.0.5

- Rejected malformed Unicode in saved hero, room, and enemy text before it could crash rendering.
- Rejected unknown save states instead of silently returning to town and banking carried treasure.
- Rejected false victory markers and impossible Classic-mode death saves.
- Rejected self-looped and duplicate room links that could trap movement or retreat logic.
- Preserved safe loading of legacy title, creation, and instructions saves from early releases.

## 1.0.4

- Rejected damaged combat saves whose retreat position is neither the current room nor an adjacent room.
- Prevented corrupted retreat data from teleporting a character across the dungeon after evasion.

## 1.0.3

- Fixed resting ambushes being bypassed when evasion tried to retreat into the current room.
- Made evasion choose an adjacent retreat from a same-room ambush and mark that destination visited.
- Made retreating into another occupied room immediately begin its waiting encounter.

## 1.0.2

- Fixed closing the game from the title, instructions, or creation screen overwriting an active expedition as a town save.
- Rejected disconnected or stairless damaged dungeon saves before they could trap a character.
- Made completed victories take precedence over stale location data when loading.
- Added consistency checks for the entrance and current room's visited state.
- Rejected Boolean save-format markers and unreasonably large damaged text fields.

## 1.0.1

- Fixed damaged saves with a malformed destination room bypassing validation and crashing the loader.
- Rebalanced later encounters so monster offense no longer outgrows every class's defenses.
- Added gradual depth-based attack growth so all class and species combinations remain viable.
- Strengthened the Mage's arcane bolt and base protection so its low-health playstyle remains viable.
- Restored inconsistent room saves directly into their waiting encounter instead of allowing an enemy to be bypassed.
- Made the title screen read the actual release version instead of displaying a stale hard-coded number.
- Hardened mouse-coordinate conversion for minimized and extremely small windows.

## 1.0.0

- Created a separate room-driven dungeon RPG inspired by DEC-era DND.
- Replaced tile-by-tile movement with N, S, E, and W passage commands.
- Added full-screen room scenes and immediate encounter transitions.
- Added twenty procedural dungeon levels, four named guardians, and the Orb ending.
- Added six furry species, four freely combinable classes, and unique portraits.
- Added Adventure and Classic modes, atomic saves, mouse control, fullscreen, music, and sound effects.
